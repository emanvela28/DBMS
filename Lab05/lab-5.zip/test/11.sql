SELECT 
    SUM(ps.ps_supplycost) AS total_supply_cost
FROM 
    part p
JOIN 
    partsupp ps ON p.p_partkey = ps.ps_partkey
JOIN 
    lineitem l ON ps.ps_suppkey = l.l_suppkey AND ps.ps_partkey = l.l_partkey
WHERE 
    p.p_retailprice < 1500 AND l.l_shipdate BETWEEN '1996-01-01' AND '1996-12-31'
    AND ps.ps_suppkey NOT IN (
SELECT 
    l2.l_suppkey
FROM 
    lineitem l2
WHERE 
    l2.l_extendedprice < 1800 AND l2.l_shipdate BETWEEN '1998-01-01' AND '1998-12-31'
);